const router=require('express').Router()
const Book=require('./models/book')

router.get('/',async(req,res)=>{
  const records=  await Book.find()
res.json(records)
})

router.get('/:id',async(req,res)=>{
const record=await Book.findById(req.params.id)
res.json(record)
})

router.post('/',(req,res)=>{
    const{name,img,author,pages,price}=req.body
  const record=  new Book({name:name,img:img,author:author,pages:pages,price:price})
    record.save()
    res.json("Successfully Created")
})

router.delete('/:id',async(req,res)=>{
   const record= await Book.findByIdAndDelete(req.params.id)
   res.json("Succsfully Deleted")
})

router.put('/:id',async(req,res)=>{
const{name,img,author,pages,price}=req.body
const record=  await Book.findByIdAndUpdate(req.params.id,{name:name,img:img,author:author,pages:pages,price:price})
res.json("Successfully Updated")
})

module.exports=router