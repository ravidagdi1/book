const express=require('express')
const app= express()
const mongoose=require('mongoose')
const apiRouter=require('./api')
app.use(express.json())
mongoose.connect('mongodb://127.0.0.1:27017/arjun1pi')

app.use('/api',apiRouter)
app.listen(5000)