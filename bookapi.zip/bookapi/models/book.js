const mongoose = require('mongoose')


const bookSchema =mongoose.Schema({
    name:String,
    img:String,
    author:String,
    pages:String,
    price:Number
})


  module.exports= mongoose.model('book',bookSchema)


